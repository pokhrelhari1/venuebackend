msg='HEllO WORLD!'
print(msg)